"""
Windows Device Tracking Agent
------------------------------
Collects hardware stats + connected device info from this Windows PC
and POSTs it to your central server every REPORT_INTERVAL seconds.

Requirements (install with pip):
    pip install psutil requests wmi pywin32

Run:
    python agent_windows.py
"""

import platform
import socket
import time
import uuid
import json

import psutil
import requests
import wmi

# ----------------- CONFIG -----------------
SERVER_URL = "http://localhost:8000/api/report"   # <-- change this to your server's address
API_KEY = "changeme-shared-secret"                      # <-- must match server's API_KEY
REPORT_INTERVAL = 5                                      # seconds between reports
# -------------------------------------------

# A stable ID for this machine (based on MAC address, stays the same across reboots)
DEVICE_ID = f"{socket.gethostname()}-{uuid.getnode():x}"


def get_hardware_stats():
    """Collect CPU / RAM / disk stats using psutil (cross-platform, but we only run this on Windows here)."""
    disk = psutil.disk_usage("C:\\")
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.5),
        "ram_percent": psutil.virtual_memory().percent,
        "ram_used_gb": round(psutil.virtual_memory().used / (1024 ** 3), 2),
        "ram_total_gb": round(psutil.virtual_memory().total / (1024 ** 3), 2),
        "disk_percent": disk.percent,
        "disk_free_gb": round(disk.free / (1024 ** 3), 2),
        "battery_percent": (psutil.sensors_battery().percent if psutil.sensors_battery() else None),
    }


def get_connected_devices():
    """Enumerate connected/plugged-in devices using WMI (Windows-only)."""
    c = wmi.WMI()
    devices = []

    # USB / Plug-and-Play devices
    for entry in c.Win32_PnPEntity():
        if entry.Name and entry.Status == "OK":
            devices.append({
                "type": "pnp",
                "name": entry.Name,
                "device_id": entry.DeviceID,
            })

    # Physical disks (covers external USB drives too)
    for disk in c.Win32_DiskDrive():
        devices.append({
            "type": "disk",
            "name": disk.Model,
            "interface": disk.InterfaceType,
            "size_gb": round(int(disk.Size) / (1024 ** 3), 2) if disk.Size else None,
        })

    return devices


def get_custom_data():
    """
    Placeholder for whatever app-specific data you want to send.
    Replace this with real data from your own app/process.
    """
    return {
        "note": "replace get_custom_data() with your real app data"
    }


def build_payload():
    return {
        "device_id": DEVICE_ID,
        "hostname": socket.gethostname(),
        "os": f"{platform.system()} {platform.release()}",
        "timestamp": time.time(),
        "hardware": get_hardware_stats(),
        "devices": get_connected_devices(),
        "custom": get_custom_data(),
    }


def send_report(payload):
    try:
        resp = requests.post(
            SERVER_URL,
            headers={"X-API-Key": API_KEY, "Content-Type": "application/json"},
            data=json.dumps(payload),
            timeout=5,
        )
        if resp.status_code == 200:
            print(f"[OK] Reported at {time.strftime('%H:%M:%S')}")
        else:
            print(f"[WARN] Server responded {resp.status_code}: {resp.text}")
    except requests.RequestException as e:
        print(f"[ERROR] Could not reach server: {e}")


def main():
    print(f"Starting agent for device: {DEVICE_ID}")
    print(f"Reporting to: {SERVER_URL} every {REPORT_INTERVAL}s")
    while True:
        payload = build_payload()
        send_report(payload)
        time.sleep(REPORT_INTERVAL)


if __name__ == "__main__":
    main()
